export default function CompanyPage() {
    return (
      <div>
        <h1>About The Company</h1>
        <p>This is a dummy page for The Company link.</p>
      </div>
    );
  }